﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_obs.Modelo;
using Base_de_Datos.DB;
using AutoMapper;

namespace ms_obs.Negocio
{
    public class NegocioObs : IObs
    {

        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public NegocioObs(RRHHContext db, IMapper mapper) {
            _db = db;
            _mapper = mapper;
        }

        public void BorrarObservacion(int CodObs)
        {
            var result = _db.TblObs.FirstOrDefault(c => c.CodObs == CodObs);

            _db.TblObs.Remove(result);

            _db.SaveChanges();
        }

        public void CrearObservacion(Observacion obs)
        {
            TblObs observaciones = new TblObs
            {
                Obs = obs.Obs
            };
            _db.TblObs.Add(observaciones);
            _db.SaveChanges();
        }

        public Observacion GetObservacion(int codObs)
        {
            return _mapper.Map<Observacion>(_db.TblObs.FirstOrDefault(c => c.CodObs == codObs));
        }

        public List<Observacion> GetObservaciones()
        {
            return _mapper.Map<List<Observacion>>(_db.TblObs.ToList());
        }




        public void ModificarObservacion(int CodObs, Observacion obs)
        {
            var result = _db.TblObs.FirstOrDefault(c => c.CodObs == CodObs);

            if (obs.Obs!=null)
            {
                result.Obs = obs.Obs;
            }

            _db.Entry(result).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
            _db.SaveChanges();




        }
    }
}

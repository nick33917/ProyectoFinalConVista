﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
namespace ms_usuario.Modelo
{
    public class Usuario
    {

        public DateTime? ActualStart { get; set; }
        public DateTime? PlannedEnd { get; set; }
        public DateTime? ActualEnd { get; set; }
        public string Observaciones { get; set; }
        public decimal? Galar { get; set; }
        public string NroEmpleadoAcc { get; set; }
        public DateTime? PlannedStart { get; set; }
        public string EnterpriseIdacc { get; set; }
        public int? CodSkill { get; set; }
        public DateTime? IngresoAccenture { get; set; }
        public string SerialNumberNotebook { get; set; }
        public DateTime? RequestDate { get; set; }
        public int? CodGerente { get; set; }
        public int CodUsuario { get; set; }
        public int? CodCategoria { get; set; }
        public int? CodAcuerdoOriginal { get; set; }
        public string NombreUsuario { get; set; }
        public string Apellidousuario { get; set; }
        public string Legajo { get; set; }
        public int? CodPerfil { get; set; }
        public int? NumEmpleado { get; set; }
        public int? CodSupervisor { get; set; }
        public string Foto { get; set; }
        public DateTime? FechaNacimiento { get; set; }
        public int? CodCompany { get; set; }
        public int? CodObs { get; set; }
        public int? CodEspecialista { get; set; }
        public int? Estado { get; set; }

    }
}

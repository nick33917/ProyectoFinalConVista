﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_usuario.Modelo;

namespace ms_usuario.Cqrs.Commands
{
    public class PutUsuarioCommand : IRequest<bool>
    {
        public int CodUser { get; set; }
        public Usuario User { get; set; }
    }
}

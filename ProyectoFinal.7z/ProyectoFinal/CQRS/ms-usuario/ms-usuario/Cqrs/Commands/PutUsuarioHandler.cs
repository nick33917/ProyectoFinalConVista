﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using AutoMapper;
using ms_usuario.Modelo;
using System.Threading;
using Base_de_Datos.DB;
using Microsoft.EntityFrameworkCore;

namespace ms_usuario.Cqrs.Commands
{
    public class PutUsuarioHandler : Profile , IRequestHandler<PutUsuarioCommand, bool>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;

        public PutUsuarioHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PutUsuarioCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var obj = _db.TblUsuarios.FirstOrDefault(c => c.CodUsuario == request.CodUser);
                var objTblUser = _mapper.Map(request.User,obj , typeof(Usuario), typeof(TblUsuarios));
                // ().ForMember(c => c.CodUsuario, opt => opt.Ignore())


                _db.Entry(objTblUser).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                //Console.WriteLine(objTblUser.ToString());
                rtn = true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return rtn;
        }
    }
}

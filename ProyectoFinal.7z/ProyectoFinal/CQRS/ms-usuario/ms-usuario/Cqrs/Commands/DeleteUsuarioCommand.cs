﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_usuario.Modelo;

namespace ms_usuario.Cqrs.Commands
{
    public class DeleteUsuarioCommand : IRequest<bool>
    {
        public int CodUsusario { get; set; }
    }
}

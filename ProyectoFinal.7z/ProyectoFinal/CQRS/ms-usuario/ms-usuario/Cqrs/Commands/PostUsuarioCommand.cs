﻿using MediatR;
using ms_usuario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_usuario.Cqrs.Commands
{
    public class PostUsuarioCommand : IRequest<bool>
    {
       public Usuario usuario { get; set; }
    }
}

﻿using MediatR;
using ms_usuario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_usuario.Cqrs.Queries
{
    public class GetUsuarioQuery : IRequest<Usuario>
    {
        public int CodUsuario { get; set; }
    }
}

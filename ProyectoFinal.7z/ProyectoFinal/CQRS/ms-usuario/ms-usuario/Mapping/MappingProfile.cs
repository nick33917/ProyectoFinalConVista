﻿using AutoMapper;
using ms_usuario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;

namespace ms_usuario.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Mapper para el POST/PUT
            CreateMap<Usuario, TblUsuarios>()
            .ForMember(s => s.CodUsuario, opt => opt.Condition(s => (s.CodUsuario == 0)));
            
            //Mapper para el GET
            CreateMap<TblUsuarios, Usuario>();

            
        }
        
    }
}

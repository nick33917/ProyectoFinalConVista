﻿using ms_usuario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_usuario.Negocio
{
    public interface INegocioUsuario
    {
        Task<List<Usuario>> GetUsuarios();
        Task<Usuario> GetUsuario(int CodUsuario);
        Task<bool> CrearUsuario(Usuario usuario);
        Task<bool> BorrarUsuario(int CodUsuario);
        Task<bool> ModificarUsuario(int codUsuario, Usuario usuario);
    }
}

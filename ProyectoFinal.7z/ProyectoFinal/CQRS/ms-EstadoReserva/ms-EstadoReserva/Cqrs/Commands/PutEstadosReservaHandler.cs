﻿using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Commands
{
    public class PutEstadosReservaHandler : IRequestHandler<PutEstadosReservaCommands,bool>
    {
        public readonly RRHHContext _db;

        public PutEstadosReservaHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(PutEstadosReservaCommands request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblEstadoReserva.FirstOrDefault(c => c.EstadoReservaId == request.EstadoreservaId);
                result.Descripcion = request.UnEstadoReserva.Descripcion;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn= true;
            }
            catch
            {

            }
            return rtn;
            
        }
    }
}

﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Commands
{
    public class PostEstadoReservaHandler : IRequestHandler<PostEstadoReservaCommands, bool>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostEstadoReservaHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<bool> Handle(PostEstadoReservaCommands request, CancellationToken cancellationToken)
        {
            try
            {/*
                TblEstadoReserva tblEstadoReserva = new TblEstadoReserva
                {
                    EstadoReservaId = request.UnEstadoReserva.EstadoReservaId,
                    Descripcion = request.UnEstadoReserva.Descripcion
                };*/
                var obj = _mapper.Map<TblEstadoReserva>(request.UnEstadoReserva);
                await _db.TblEstadoReserva.AddAsync(obj);
                await _db.SaveChangesAsync();
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}

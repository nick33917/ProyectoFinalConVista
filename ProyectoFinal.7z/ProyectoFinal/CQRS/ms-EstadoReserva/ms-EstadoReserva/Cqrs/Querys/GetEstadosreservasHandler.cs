﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_EstadoReserva.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Querys
{
    public class GetEstadosreservasHandler : IRequestHandler<GetEstadosreservasQuery, List<Estadoreserva>>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;

        public GetEstadosreservasHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<Estadoreserva>> Handle(GetEstadosreservasQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<Estadoreserva>>(await _db.TblEstadoReserva.ToListAsync());
        }
    }
}

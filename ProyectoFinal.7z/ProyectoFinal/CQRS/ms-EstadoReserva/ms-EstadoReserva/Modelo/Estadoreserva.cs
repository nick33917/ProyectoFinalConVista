﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;

namespace ms_EstadoReserva.Modelo
{
    public class Estadoreserva
    {

        public int EstadoReservaId { get; set; }
        public string Descripcion { get; set; }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_reserva.Modelo;

namespace ms_reserva.Negocio
{
    public class NegocioReserva : INegocioReserva
    {
        public Task<bool> BorrarReserva(int codReserva)
        {
            throw new NotImplementedException();
        }

        public Task<bool> CrearReserva(Reserva reserva)
        {
            throw new NotImplementedException();
        }

        public Task<Reserva> GetReserva(int codReserva)
        {
            throw new NotImplementedException();
        }

        public Task<List<Reserva>> GetReservas()
        {
            throw new NotImplementedException();
        }

        public Task<bool> ModificarReserva(int codReserva, Reserva reserva)
        {
            throw new NotImplementedException();
        }
    }
}

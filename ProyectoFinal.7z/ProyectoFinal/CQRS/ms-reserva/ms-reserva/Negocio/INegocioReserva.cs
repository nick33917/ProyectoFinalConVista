﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_reserva.Modelo;

namespace ms_reserva.Negocio
{
    public interface INegocioReserva
    {
        Task<List<Reserva>> GetReservas();
        Task<Reserva> GetReserva(int codReserva);
        Task<bool> CrearReserva(Reserva reserva);
        Task<bool> BorrarReserva(int codReserva);
        Task<bool> ModificarReserva(int codReserva, Reserva reserva);
    }
}

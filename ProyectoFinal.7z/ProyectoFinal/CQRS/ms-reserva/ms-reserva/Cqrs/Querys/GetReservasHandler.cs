﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;
using MediatR;

namespace ms_reserva.Cqrs.Querys
{
    public class GetReservasHandler
    {
    }
}

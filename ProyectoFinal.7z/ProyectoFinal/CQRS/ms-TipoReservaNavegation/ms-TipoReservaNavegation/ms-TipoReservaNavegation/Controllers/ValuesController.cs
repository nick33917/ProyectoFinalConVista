﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using ms_TipoReservaNavigation.Negocio;
using ms_TipoReservaNavigation.Modelo;

namespace ms_TipoReservaNavigation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {

        private readonly INegocioTipoReservaNavigation _negocioTipoReservaNavigation;

        public ValuesController(INegocioTipoReservaNavigation negocioTipoReservaNavigation)
        {
            _negocioTipoReservaNavigation = negocioTipoReservaNavigation;
        }

        // GET ALL
        [HttpGet]
       public async Task<ActionResult<List<TipoReservaNavigation>>> Get()
        {
            return await _negocioTipoReservaNavigation.GetTipoReservaNavigation();
        }


        // GET ID
        [HttpGet("{id}")]
        public async Task<ActionResult<TipoReservaNavigation>> Get(int id)
        {
            return await _negocioTipoReservaNavigation.GetUnTipoReservaNavigation(id);

        }
        
        // POST - Crear
        [HttpPost]
        public async Task<bool> Post([FromBody] TipoReservaNavigation value)
        {
            return await _negocioTipoReservaNavigation.CrearTipoReservaNavigation(value);

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool> Put(int id, [FromBody] TipoReservaNavigation value)
        {
            return await _negocioTipoReservaNavigation.ModificarTipoReservaNavigation(id, value);

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            return await _negocioTipoReservaNavigation.BorrarTipoReservaNavigation(id);


        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_evaluacion.Modelo;
using Base_de_Datos.DB;

namespace ms_evaluacion.Negocio
{
    public interface INegocioEvaluacion
    {
        
        Task<List<Evaluacion>> GetEvaluaciones();
        Task<Evaluacion> GetEvaluacion(int IdItemEvaluacion);
        Task<bool> CrearEvaluacion(Evaluacion evaluacion);
        Task<bool> BorrarEvaluacion(int IdItemEvaluacion);
        Task<bool> ModificarEvaluacion(int IdItemEvaluacion, Evaluacion evaluacion);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using MediatR;
using AutoMapper;
using Base_de_Datos.DB;
using ms_mail.Modelo;
using System.Threading;
using Microsoft.EntityFrameworkCore;


namespace ms_mail.CQRS.Command
{
    public class PostMailHandler : IRequestHandler<PostMailCommand, bool>
    {

        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public PostMailHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }


        public async Task<bool> Handle(PostMailCommand request, CancellationToken cancellationToken)
        {
            
            try
            {
                TblUsuariosMail mail = new TblUsuariosMail
                {
                    IdMail = request.UnMail.IdMail,
                    CodUsuario = request.UnMail.CodUsuario,
                    Mail = request.UnMail.Mail,
                    Tipo = request.UnMail.Tipo
                };
                await _db.TblUsuariosMail.AddAsync(mail);
                await _db.SaveChangesAsync();
                return true;

            }
            catch
            {
                return false;
            }



        }
    }
}

﻿using MediatR;
using ms_mail.CQRS.Query;
using ms_mail.Modelo;
using System.Collections.Generic;
using System.Threading.Tasks;
using ms_mail.CQRS.Command;


namespace ms_mail.Negocio
{
    public class NegocioMail : INegocioMail
    {
        private readonly IMediator _mediator;

        public NegocioMail(IMediator mediator)
        {
            _mediator = mediator;
        }

        //GET ALL
        public async Task<List<UserMail>> GetMails()
        {

            return await _mediator.Send(new GetMailsQuery());

        }


        //GET ID
        public async Task<UserMail> GetMail(int idMail)
        {
            return await _mediator.Send(new GetMailQuery { IdMail = idMail});
        }


        //POST - crear
        public async Task<bool> CrearMail(UserMail mail)
        {
            await _mediator.Send(new PostMailCommand { UnMail = mail });
            return true;
        }


        //PUT - modificar
        public async Task<bool> ModificarMail(int idMail, UserMail mail)
        {
            return await _mediator.Send(new PutMailCommand { IdMail = idMail, unMail = mail });
        }




        //DELETE
        public async Task<bool> BorrarMail(int idMail)
        {
            return await _mediator.Send(new DeleteMailCommand { IdMail = idMail });
        }

       
    }
}

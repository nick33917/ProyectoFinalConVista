﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_equipos.Modelo;

namespace ms_equipos.Negocio
{
    public interface INegocioEquipo
    {
        Task<List<Equipo>> GetEquipos();
        Task <Equipo> GetEquipo(int codGrupo);
        Task <Boolean> CrearEquipo(Equipo equipo);
        Task<bool> BorrarEquipo(int codEquipo);
        Task<bool> ModificarEquipo(int codEquipo, Equipo equipo);


    }
}

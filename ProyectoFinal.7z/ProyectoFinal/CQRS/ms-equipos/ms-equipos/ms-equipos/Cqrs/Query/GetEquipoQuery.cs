﻿using MediatR;
using ms_equipos.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_equipos.Cqrs.Query
{
    public class GetEquipoQuery : IRequest<Equipo>
    {
        public int CodGrupo { get; set; }
    }
}

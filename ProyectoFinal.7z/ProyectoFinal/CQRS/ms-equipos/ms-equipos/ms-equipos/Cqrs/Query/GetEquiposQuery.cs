﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Base_de_Datos;
using ms_equipos.Modelo;

namespace ms_equipos.Cqrs.Query
{
    public class GetEquiposQuery : IRequest <List<Equipo>>
    {

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_puesto.Modelo;

namespace ms_puesto.CQRS.Commands
{
    public class PutPuestoCommand : IRequest<bool>
    {
        public string nroPuesto { get; set; }
        public Puesto unPuesto { get; set; }
    }
}

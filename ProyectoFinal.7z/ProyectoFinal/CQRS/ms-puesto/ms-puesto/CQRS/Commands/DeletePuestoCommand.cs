﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_puesto.CQRS.Commands
{
    public class DeletePuestoCommand : IRequest<bool>
    {
        public int CodUsuario { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_puesto.Modelo;
using MediatR;

namespace ms_puesto.CQRS.Commands
{
    public class PostPuestoCommand:IRequest<bool>
    {
        public Puesto Puesto { get; set; }

    }
}

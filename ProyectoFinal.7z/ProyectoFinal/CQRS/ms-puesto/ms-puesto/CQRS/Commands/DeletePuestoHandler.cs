﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_puesto.CQRS.Commands
{
    public class DeletePuestoHandler : IRequestHandler<DeletePuestoCommand, bool>
    {
        private readonly RRHHContext _db;

        public DeletePuestoHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeletePuestoCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblPuesto.FirstOrDefault(c => c.CodUsuario == request.CodUsuario);
                 _db.TblPuesto.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return rtn;
        }
    }
}

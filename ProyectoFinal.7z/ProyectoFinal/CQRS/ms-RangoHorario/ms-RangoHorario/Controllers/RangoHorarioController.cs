﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_RangoHorario.Modelo;
using ms_RangoHorario.Negocio;

namespace ms_RangoHorario.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RangoHorarioController : ControllerBase
    {
        private readonly INegocioRangoHorario _negocioEstadoReserva;

        public RangoHorarioController(INegocioRangoHorario negocioEstadoReserva)
        {
            _negocioEstadoReserva = negocioEstadoReserva;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<RangoHorario>>> Get()
        {
            return await _negocioEstadoReserva.GetRangoHorarios();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<ActionResult<RangoHorario>> Get(int id)
        {
            return await _negocioEstadoReserva.GetRangoHorario(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] RangoHorario UnRango)
        {
            bool x = await _negocioEstadoReserva.CrearRangoHorario(UnRango);
            return x;
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool> Put(int id, [FromBody] RangoHorario UnRango)
        {
            return await _negocioEstadoReserva.ModificarRangoHorario(id, UnRango);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            return await _negocioEstadoReserva.BorrarRangoHorario(id); 
        }
    }
}

﻿using MediatR;
using ms_RangoHorario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Querys
{
    public class GetRangoHorarioQuery : IRequest <RangoHorario>
    {
        public int Ranho { get; set; }
    }
}

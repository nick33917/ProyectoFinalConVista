﻿using MediatR;
using ms_RangoHorario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Commands
{
    public class PutRangoHorarioCommands : IRequest<bool>
    {
        public int Ranho { get; set; }
        public RangoHorario UnRango { get; set; }
    }
}

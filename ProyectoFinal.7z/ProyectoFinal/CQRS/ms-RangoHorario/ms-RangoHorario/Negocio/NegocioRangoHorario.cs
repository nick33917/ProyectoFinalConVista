﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_RangoHorario.Cqrs.Commands;
using ms_RangoHorario.Cqrs.Querys;
using ms_RangoHorario.Modelo;

namespace ms_RangoHorario.Negocio
{
    public class NegocioRangoHorario : INegocioRangoHorario
    {
        private readonly IMediator _mediator;

        public NegocioRangoHorario(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<bool> BorrarRangoHorario(int Ranho)
        {
            return await _mediator.Send(new DeleteRangoHorarioCommands { Ranho = Ranho });
        }

        public async Task<bool> CrearRangoHorario(RangoHorario UnRango)
        {
            return await _mediator.Send(new PostRangoHorarioCommands { UnRango = UnRango });

        }

        public async Task<RangoHorario> GetRangoHorario(int Ranho)
        {
            return await _mediator.Send(new GetRangoHorarioQuery { Ranho = Ranho });
        }

        public async Task<List<RangoHorario>> GetRangoHorarios()
        {
            return await _mediator.Send(new GetRangoHorariosQuery());
        }

        public async Task<bool> ModificarRangoHorario(int Ranho, RangoHorario UnRango)
        {
            return await _mediator.Send(new PutRangoHorarioCommands { Ranho = Ranho, UnRango  = UnRango });
        }
    }
}

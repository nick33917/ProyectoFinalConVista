﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_estado.Modelo;
using MediatR;
using System.Threading;
using Base_de_Datos.DB;
using Microsoft.EntityFrameworkCore;

namespace ms_estado.Cqrs.Commands
{
    public class PutEstadoHandler : IRequestHandler<PutEstadoCommand, bool>
    {
        public readonly RRHHContext _db;
        public PutEstadoHandler(RRHHContext db)
        {
            _db = db;
        }
        public async Task<bool> Handle(PutEstadoCommand request, CancellationToken cancellationToken)
        {
            bool rtn=false;
            try
            {
                var result = _db.TblEstados.FirstOrDefault(c => c.CodEstado == request.codEstado);
                result.CodTipoGalar = request.unEstado.CodTipoGalar;
                result.DescripcionEstado = request.unEstado.DescripcionEstado;

                _db.Entry(result).State = EntityState.Modified;
                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {

            }
            return rtn;


        }
    }
}

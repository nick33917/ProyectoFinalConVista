﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblObs
    {
        public int CodObs { get; set; }
        public string Obs { get; set; }
    }
}

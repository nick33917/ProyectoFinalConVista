﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblDetalleHorasGestionGop
    {
        public int CodDetalle { get; set; }
        public int? CodUsuario { get; set; }
        public int? Codperiodo { get; set; }
        public int? Año { get; set; }
        public int? CodSemana { get; set; }
        public int? CodGestionOperativa { get; set; }
        public decimal? Incurrido { get; set; }
    }
}

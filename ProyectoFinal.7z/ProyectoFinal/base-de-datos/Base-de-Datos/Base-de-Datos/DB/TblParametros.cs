﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblParametros
    {
        public int CodParametro { get; set; }
        public string DesParametro { get; set; }
        public string DesValor { get; set; }
    }
}

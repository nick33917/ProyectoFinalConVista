﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildHistoryEstadistica
    {
        public long IdReorgHistoryStats { get; set; }
        public DateTime? Fechaejecucion { get; set; }
        public string Groupname { get; set; }
        public string Schemaname { get; set; }
        public string Tablename { get; set; }
        public long? Numrows { get; set; }
        public string Reserved { get; set; }
        public string Data { get; set; }
        public string IndexSize { get; set; }
        public string Unused { get; set; }
        public int? Processed { get; set; }
        public decimal? Fragmentacion { get; set; }
        public decimal? FragmentacionFinal { get; set; }
        public string AccionTomada { get; set; }
        public int? Idcalculostats { get; set; }
        public string JobId { get; set; }
    }
}

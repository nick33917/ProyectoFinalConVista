﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblGruposGop
    {
        public int CodGrupoGop { get; set; }
        public string NombreGrupoGop { get; set; }
        public int CodGrupo { get; set; }
    }
}

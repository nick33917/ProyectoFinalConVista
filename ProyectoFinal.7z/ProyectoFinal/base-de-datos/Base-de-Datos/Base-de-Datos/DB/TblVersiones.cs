﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblVersiones
    {
        public string CodPeriodo { get; set; }
        public string Anio { get; set; }
        public int CodGrupo { get; set; }
        public double NumVersion { get; set; }
        public string Descripcion { get; set; }
        public DateTime? Fecha { get; set; }
    }
}

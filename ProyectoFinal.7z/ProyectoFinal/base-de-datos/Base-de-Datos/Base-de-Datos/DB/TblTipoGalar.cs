﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblTipoGalar
    {
        public TblTipoGalar()
        {
            TblGalar = new HashSet<TblGalar>();
        }

        public int CodTipoGalar { get; set; }
        public string DescripcionTipoGalar { get; set; }

        public virtual ICollection<TblGalar> TblGalar { get; set; }
    }
}

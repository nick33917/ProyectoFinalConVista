﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ms_categorias.Negocio;
using ms_categorias.Modelo;
using System.Threading.Tasks;

namespace ms_categorias.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriasController : ControllerBase
    {
        private readonly INegocioCategorias _negocioCategorias;
        public CategoriasController(INegocioCategorias negocioCategorias)
        {
            _negocioCategorias = negocioCategorias;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Categoria>>>Get()
        {
            return await _negocioCategorias.GetCategorias();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Categoria>> Get(int id)
        {
            return await _negocioCategorias.GetCategoria(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] Categoria value)
        {
            return await _negocioCategorias.CrearCategoria(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Categoria value)
        {
            _negocioCategorias.ModificarCategoria(id, value);
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            return await _negocioCategorias.BorrarCategoria(id);
        }
    }
}

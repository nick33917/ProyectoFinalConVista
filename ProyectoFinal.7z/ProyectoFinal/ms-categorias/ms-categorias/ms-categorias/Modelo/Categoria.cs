﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_categorias.Modelo
{
    public class Categoria
    {
        public int CodCategoria { get; set; }
        public string NombreCategoria { get; set; }
        public string Level { get; set; }
        public string Skill { get; set; }
    }
}

﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_categorias.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Querys
{
    public class GetCategoraHandler : IRequestHandler<GetCategoriaQuery, Categoria>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetCategoraHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;

        }
        public async Task<Categoria> Handle(GetCategoriaQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<Categoria>(await _db.TblCategorias.FirstOrDefaultAsync(c => c.CodCategoria == request.codCategoria));
        }
    }
}

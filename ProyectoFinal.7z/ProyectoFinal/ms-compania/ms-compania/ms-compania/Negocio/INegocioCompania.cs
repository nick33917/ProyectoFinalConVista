﻿using ms_compania.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_compania.Negocio
{
    public interface INegocioCompania
    {
        List<Compania> GetCompanias();
        Compania GetCompania(int codCompania);
        void CrearCompania(Compania Compania);
        void BorrarCompania(int codCompania);
        void ModificarCompania(int codCompania, Compania categoria);
    }
}

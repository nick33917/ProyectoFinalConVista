﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_puesto.CQRS.Queries;
using MediatR;
using System.Threading;
using Base_de_Datos.DB;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using ms_puesto.Modelo;

namespace ms_puesto.CQRS.Queries
{
    public class GetPuestosHandler : IRequestHandler<GetPuestosQuery, List<Puesto>>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;
        public GetPuestosHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;

        }
        public async Task<List<Puesto>> Handle(GetPuestosQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<Puesto>>(await _db.TblPuesto.ToListAsync());
        }
    }
}

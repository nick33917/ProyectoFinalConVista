﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_puesto.Modelo;
using AutoMapper;
using Base_de_Datos.DB;
using System.Threading;
using Microsoft.EntityFrameworkCore;

namespace ms_puesto.CQRS.Queries
{
    public class GetPuestoHandler : IRequestHandler<GetPuestoQuery, Puesto>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _map;
        public GetPuestoHandler(RRHHContext db, IMapper map)
        {
            _db = db;
            _map = map;
        }

        public async Task<Puesto> Handle(GetPuestoQuery request, CancellationToken cancellationToken)
        {
            return _map.Map<Puesto>(await _db.TblPuesto.FirstOrDefaultAsync(c => c.NroPuesto == request.NroPuesto));
        }
    }
}

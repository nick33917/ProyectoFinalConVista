﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_puesto.Modelo
{
    public class Puesto
    {

        public int CodUsuario { get; set; }
        public string NroPuesto { get; set; }
        public string NroBoca { get; set; }
        public string Galcpu { get; set; }
        public string Galmonitor { get; set; }
        public string Galtelefono { get; set; }
        public string InternoAcc { get; set; }
        public int? CodInternoAccTitular { get; set; }
        public string InternoGalicia { get; set; }
        public int? CodInternoGaliciaTitular { get; set; }
        public string Galcpuextra { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MediatR;
using ms_puesto.Negocio;
using ms_puesto.Modelo;

namespace ms_puesto.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PuestoController : ControllerBase
    {
        private readonly INegocioPuesto _negocioPuesto;

        public PuestoController( INegocioPuesto negocioPuesto)
        {
            _negocioPuesto = negocioPuesto;
        }

        // GET api/values
        [HttpGet]
        public async Task<ActionResult<List<Puesto>>> Get()
        {
            return await _negocioPuesto.GetPuestos();
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public async Task <ActionResult<Puesto>> Get(string id)
        {
            return await _negocioPuesto.GetPuesto(id);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] Puesto value)
        {
            return await _negocioPuesto.CrearPuesto(value);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool>Put(string id, [FromBody] Puesto value)
        {
            return await _negocioPuesto.ModificarPuesto(id,value);
        }

        // DELETE api/values/5
        [HttpDelete("{codUsuario}")]
        public  async Task<bool> Delete(int codUsuario)
        {
            return await _negocioPuesto.BorrarPuesto(codUsuario);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ms_mail.Modelo;
using ms_mail.Negocio;
using ms_mail.Controllers;

namespace ms_mail.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MailController : ControllerBase
    {
        private readonly INegocioMail _negocioMail;

        public MailController(INegocioMail negocioMail)
        {
            _negocioMail = negocioMail;
        }


        // GET all
        [HttpGet]
        public async Task<ActionResult<List<UserMail>>> Get()
        {
            return await _negocioMail.GetMails();

        }

        // GET id
        [HttpGet("{idMail}")]
        public async Task<ActionResult<UserMail>> Get(int idMail)
        {
            return await _negocioMail.GetMail(idMail);
        }

        // POST api/values
        [HttpPost]
        public async Task<bool> Post([FromBody] UserMail mail)
        {
           return await _negocioMail.CrearMail(mail);

        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public async Task<bool> Put(int id, [FromBody] UserMail value)
        {
            return await _negocioMail.ModificarMail(id, value);

        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public async Task<bool> Delete(int id)
        {
            return await _negocioMail.BorrarMail(id);

        }
    }
}

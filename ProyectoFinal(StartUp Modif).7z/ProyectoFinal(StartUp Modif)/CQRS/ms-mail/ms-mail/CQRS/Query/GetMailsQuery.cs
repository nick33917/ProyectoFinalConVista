﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_mail.Modelo;

namespace ms_mail.CQRS.Query
{
    public class GetMailsQuery : IRequest<List<UserMail>>
    {
    }
}

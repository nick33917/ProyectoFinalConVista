﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;

namespace ms_mail.CQRS.Command
{
    public class DeleteMailCommand : IRequest <bool>
    {
        public int IdMail { get; set; }
    }
}

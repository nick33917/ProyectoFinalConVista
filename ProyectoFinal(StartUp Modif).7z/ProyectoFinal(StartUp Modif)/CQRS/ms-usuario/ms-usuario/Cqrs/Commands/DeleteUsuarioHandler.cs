﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_usuario.Modelo;
using System.Threading;
using Base_de_Datos.DB;

namespace ms_usuario.Cqrs.Commands
{
    public class DeleteUsuarioHandler : IRequestHandler<DeleteUsuarioCommand, bool>
    {
        private readonly RRHHContext _db;

        public DeleteUsuarioHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteUsuarioCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;
            try
            {
                var result = _db.TblUsuarios.FirstOrDefault(c => c.CodUsuario == request.CodUsusario);
                _db.TblUsuarios.Remove(result);

                await _db.SaveChangesAsync();
                rtn = true;

            }
            catch
            {

            }
            return rtn;
        }
    }
}

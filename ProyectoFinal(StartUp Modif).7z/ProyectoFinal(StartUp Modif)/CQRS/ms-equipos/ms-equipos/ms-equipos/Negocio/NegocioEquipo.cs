﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using ms_equipos.Modelo;
using Base_de_Datos.DB;
using Newtonsoft.Json;
using Microsoft.EntityFrameworkCore;
using ms_equipos.Cqrs.Query;
using MediatR;
using ms_equipos.Cqrs.commands;

namespace ms_equipos.Negocio
{
    public class NegocioEquipo : INegocioEquipo
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;
        private readonly IMediator _mediatr;

         public NegocioEquipo(RRHHContext db, IMapper mapper, IMediator mediatr)
         {
            _db = db;
            _mapper = mapper;
            _mediatr = mediatr;

         }

        public async Task<bool> BorrarEquipo(int codEquipo)
        {
            return await _mediatr.Send(new DeleteEquipoCommand { codGrupo = codEquipo });
        }

        public async Task<bool> CrearEquipo(Equipo equipo)
        {
            return await _mediatr.Send(new PostEquipoCommand { grupo = equipo });

        }


        public async Task<List<Equipo>> GetEquipos()
        {
            return await _mediatr.Send(new GetEquiposQuery());

        }

        public async Task<Equipo> GetEquipo(int cod)
        {
            return await _mediatr.Send(new GetEquipoQuery { CodGrupo = cod });
        }



        public async Task<bool> ModificarEquipo(int codEquipo, Equipo equipo)
        {
            return await _mediatr.Send(new PutEquipoCommand { CodGrupo = codEquipo, grupo = equipo });
        }
    }

}
﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_equipos.Cqrs.commands
{
    public class DeleteEquipoCommand : IRequest<bool>
    {
        public int codGrupo { get; set; }
    }
}

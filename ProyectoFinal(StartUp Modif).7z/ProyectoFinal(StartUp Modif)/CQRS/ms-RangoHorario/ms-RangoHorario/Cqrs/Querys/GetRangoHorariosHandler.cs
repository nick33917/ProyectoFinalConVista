﻿using AutoMapper;
using Base_de_Datos.DB;
using MediatR;
using Microsoft.EntityFrameworkCore;
using ms_RangoHorario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_RangoHorario.Cqrs.Querys
{
    public class GetRangoHorariosHandler : IRequestHandler<GetRangoHorariosQuery, List<RangoHorario>>
    {
        public readonly RRHHContext _db;
        public readonly IMapper _mapper;

        public GetRangoHorariosHandler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<RangoHorario>> Handle(GetRangoHorariosQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<RangoHorario>>(await _db.TblRangoHorario.ToListAsync());
        }
    }
}

﻿using AutoMapper;
using Base_de_Datos.DB;
using ms_RangoHorario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_RangoHorario.Mappings
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<RangoHorario, TblRangoHorario>();
            CreateMap<TblRangoHorario, RangoHorario>();
        }
    }
}

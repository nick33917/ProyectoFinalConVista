﻿using ms_RangoHorario.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_RangoHorario.Negocio
{
    public interface INegocioRangoHorario
    {
        Task<List<RangoHorario>> GetRangoHorarios();
        Task<RangoHorario> GetRangoHorario(int Ranho);
        Task<bool> CrearRangoHorario(RangoHorario UnRango);
        Task<bool> BorrarRangoHorario(int Ranho);
        Task<bool> ModificarRangoHorario(int Ranho, RangoHorario UnRango);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using MediatR;
using Base_de_Datos.DB;
using ms_reserva.Modelo;

namespace ms_reserva.Cqrs.Querys
{
    public class GetReservasQuery : IRequest<List<Reserva>>
    {

    }
}

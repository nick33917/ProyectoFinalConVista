﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_reserva.Negocio;
using Base_de_Datos.DB;

namespace ms_reserva.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Add as many of these lines as you need to map your objects
            CreateMap<INegocioReserva,TblReservas>();
            CreateMap<TblReservas, INegocioReserva>();
        }
    }

}

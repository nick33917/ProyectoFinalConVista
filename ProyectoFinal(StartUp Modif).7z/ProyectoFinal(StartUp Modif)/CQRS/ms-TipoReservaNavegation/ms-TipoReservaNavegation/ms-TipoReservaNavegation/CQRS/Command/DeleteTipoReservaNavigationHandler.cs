﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Base_de_Datos.DB;
using MediatR;
using System.Threading;

namespace ms_TipoReservaNavegation.CQRS.Command
{
    public class DeleteTipoReservaNavigationHandler : IRequestHandler<DeleteTipoReservaNavigationCommand, bool>
    {
        private readonly RRHHContext _db;

        public DeleteTipoReservaNavigationHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteTipoReservaNavigationCommand request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblTipoReserva.FirstOrDefault(c => c.TipoReservaId == request.TipoReservaId);
                _db.TblTipoReserva.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch (Exception e )
            {
                throw;
            }

            return rtn;
        }
    }
}

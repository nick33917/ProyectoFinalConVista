﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using ms_TipoReservaNavigation.Modelo;
using MediatR;


namespace ms_TipoReservaNavegation.CQRS.Query
{
    public class GetAllTipoReservaNavigationQuery: IRequest<List<TipoReservaNavigation>>
    {
        //Nada es el GET ALL
    }
}

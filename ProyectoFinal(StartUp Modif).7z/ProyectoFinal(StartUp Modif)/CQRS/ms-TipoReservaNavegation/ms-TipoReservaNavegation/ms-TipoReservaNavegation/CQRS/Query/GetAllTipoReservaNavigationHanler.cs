﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using MediatR;
using ms_TipoReservaNavigation.Modelo;
using Base_de_Datos.DB;
using AutoMapper;
using Microsoft.EntityFrameworkCore;

namespace ms_TipoReservaNavegation.CQRS.Query
{
    public class GetAllTipoReservaNavigationHanler : IRequestHandler<GetAllTipoReservaNavigationQuery, List<TipoReservaNavigation>>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;

        public GetAllTipoReservaNavigationHanler(RRHHContext db, IMapper mapper)
        {
            _db = db;
            _mapper = mapper;
        }

        public async Task<List<TipoReservaNavigation>> Handle(GetAllTipoReservaNavigationQuery request, CancellationToken cancellationToken)
        {
            return _mapper.Map<List<TipoReservaNavigation>>(await _db.TblTipoReserva.ToListAsync());
        }

     
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Base_de_Datos.DB;
using MediatR;
using AutoMapper;
using System.Threading;
using Microsoft.EntityFrameworkCore;
using ms_TipoReservaNavigation.Controllers;
using ms_TipoReservaNavigation.Modelo;


namespace ms_TipoReservaNavegation.CQRS.Query
{
    public class GetUnTipoReservaNavigationHandler : IRequestHandler < GetUnTipoReservaNavigationQuery, TipoReservaNavigation>
    {
        private readonly RRHHContext _db;
        private readonly IMapper _map;

        public GetUnTipoReservaNavigationHandler(RRHHContext db, IMapper map)
        {
            _db = db;
            _map = map;

        }

        public async Task<TipoReservaNavigation> Handle(GetUnTipoReservaNavigationQuery request, CancellationToken cancellationToken)
        {
            return _map.Map<TipoReservaNavigation>(await _db.TblTipoReserva.FirstOrDefaultAsync(c => c.TipoReservaId == request.TipoReservaId));
        }

    }
}

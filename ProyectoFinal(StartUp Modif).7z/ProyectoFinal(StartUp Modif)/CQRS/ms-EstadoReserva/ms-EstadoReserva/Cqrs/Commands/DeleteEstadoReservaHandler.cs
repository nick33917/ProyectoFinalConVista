﻿using Base_de_Datos.DB;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Commands
{
    public class DeleteEstadoReservaHandler : IRequestHandler<DeleteEstadoReservaCommands, bool>
    {
        private readonly RRHHContext _db;

        public DeleteEstadoReservaHandler(RRHHContext db)
        {
            _db = db;
        }

        public async Task<bool> Handle(DeleteEstadoReservaCommands request, CancellationToken cancellationToken)
        {
            bool rtn = false;

            try
            {
                var result = _db.TblEstadoReserva.FirstOrDefault(c => c.EstadoReservaId == request.EstadoreservaId);
                _db.TblEstadoReserva.Remove(result);
                await _db.SaveChangesAsync();
                rtn = true;
            }
            catch
            {

            }
            return rtn;
        }
    }
}

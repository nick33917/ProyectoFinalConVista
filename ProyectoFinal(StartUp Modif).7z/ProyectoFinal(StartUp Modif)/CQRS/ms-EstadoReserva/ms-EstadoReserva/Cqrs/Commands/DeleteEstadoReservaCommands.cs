﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_EstadoReserva.Cqrs.Commands
{
    public class DeleteEstadoReservaCommands : IRequest<bool>
    {
        public int EstadoreservaId { get; set; }
    }
}

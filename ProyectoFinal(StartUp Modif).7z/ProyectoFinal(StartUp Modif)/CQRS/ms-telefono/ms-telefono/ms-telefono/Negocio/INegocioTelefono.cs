﻿using ms_telefono.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_telefono.Negocio
{
    public interface INegocioTelefono
    {
        Task<List<Telefono>>GetTelefonos();
        Task<Telefono> GetTelefono(int IdTel);
        Task<bool> CrearTelefono(Telefono telefono);
        Task<bool> BorrarTelefono(int IdTel);
        Task<bool> ModificarTelefono(int PostIdTel, Telefono unTelefono);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using ms_telefono.Cqrs.Commands;
using ms_telefono.Cqrs.Querys;
using ms_telefono.Modelo;

namespace ms_telefono.Negocio
{
    public class NegocioTelefono : INegocioTelefono
    {
        private readonly IMediator _mediator;

        public NegocioTelefono(IMediator mediator)
        {
            _mediator = mediator;
        }

        public async Task<bool> BorrarTelefono(int IdTel)
        {
            return await _mediator.Send(new DeleteTelefonoCommands { DIdtel = IdTel });
        }

        public async Task<bool> CrearTelefono(Telefono unTelefono)
        {
            return await _mediator.Send(new PostTelefonoQuery { UnTelefono = unTelefono });
        }

        public async Task<Telefono> GetTelefono(int Idtel)
        {
            return await _mediator.Send(new GetTelefonoQuery { IdTel = Idtel });
        }

        public async Task<List<Telefono>> GetTelefonos()
        {
            return await _mediator.Send(new GetTelefonosQuery());
        }

        public async Task<bool> ModificarTelefono(int IdTel, Telefono telefono)
        {
            return await _mediator.Send(new PutTelefonoCommands { PostIdTel = IdTel, unTelefono = telefono });
        }
    }
}

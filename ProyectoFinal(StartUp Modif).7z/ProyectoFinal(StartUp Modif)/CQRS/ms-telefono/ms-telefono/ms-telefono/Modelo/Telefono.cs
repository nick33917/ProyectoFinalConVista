﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Base_de_Datos.DB;


namespace ms_telefono.Modelo
{
    public class Telefono
    {
        public int CodUsuario { get; set; }
        public string Numero { get; set; }
        public string Tipo { get; set; }
        public int IdTel { get; set; }
    }
}

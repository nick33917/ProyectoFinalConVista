﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildExecutionLog
    {
        public long IdReorgExecutionLog { get; set; }
        public string Groupname { get; set; }
        public string Schemaname { get; set; }
        public string Tablename { get; set; }
        public DateTime? Ulthorainicio { get; set; }
        public DateTime? Ulthorafin { get; set; }
    }
}

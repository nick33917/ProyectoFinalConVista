﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblGrupos
    {
        public TblGrupos()
        {
            TblGruposAcuerdos = new HashSet<TblGruposAcuerdos>();
        }

        public int CodGrupo { get; set; }
        public string NombreGrupo { get; set; }
        public int? Planifica { get; set; }

        public virtual ICollection<TblGruposAcuerdos> TblGruposAcuerdos { get; set; }
    }
}

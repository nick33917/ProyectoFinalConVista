﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblHorasExtraOpp
    {
        public DateTime Fecha { get; set; }
        public string Aplicacion { get; set; }
        public string Motivo { get; set; }
        public double? Cantidadcincuenta { get; set; }
        public double? Cantidadcien { get; set; }
        public int? Responsable { get; set; }
        public string Comentarios { get; set; }
        public int Periodo { get; set; }
        public string CodUsuario { get; set; }
        public int IdHora { get; set; }
        public int? Facturable { get; set; }
        public int Aprobada { get; set; }
    }
}

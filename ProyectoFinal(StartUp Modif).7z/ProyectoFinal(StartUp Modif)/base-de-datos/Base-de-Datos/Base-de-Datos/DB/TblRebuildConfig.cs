﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRebuildConfig
    {
        public int IdReorgConfig { get; set; }
        public string Atributo { get; set; }
        public object Valor { get; set; }
        public object ValorFin { get; set; }
    }
}

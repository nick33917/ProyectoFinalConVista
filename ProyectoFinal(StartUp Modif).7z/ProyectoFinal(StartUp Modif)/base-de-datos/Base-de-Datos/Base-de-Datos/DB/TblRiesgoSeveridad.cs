﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRiesgoSeveridad
    {
        public TblRiesgoSeveridad()
        {
            TblRiesgos = new HashSet<TblRiesgos>();
        }

        public short CodSeveridad { get; set; }
        public string DescripcionSeveridad { get; set; }

        public virtual ICollection<TblRiesgos> TblRiesgos { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblRiesgoOcurrencia
    {
        public TblRiesgoOcurrencia()
        {
            TblRiesgos = new HashSet<TblRiesgos>();
        }

        public short CodOcurrencia { get; set; }
        public string Descripcionocurrencia { get; set; }

        public virtual ICollection<TblRiesgos> TblRiesgos { get; set; }
    }
}

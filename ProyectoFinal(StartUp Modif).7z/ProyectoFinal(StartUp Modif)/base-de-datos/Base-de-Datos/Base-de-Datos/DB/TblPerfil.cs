﻿using System;
using System.Collections.Generic;

namespace Base_de_Datos.DB
{
    public partial class TblPerfil
    {
        public int CodPerfil { get; set; }
        public string DesPerfil { get; set; }
    }
}

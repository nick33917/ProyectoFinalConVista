﻿using MediatR;
using ms_categorias.Modelo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ms_categorias.CQRS.Querys
{
    public class GetCategoriasQuery : IRequest<List<Categoria>>
    {
    }
}

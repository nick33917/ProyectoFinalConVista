﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ms_categorias.Modelo;
using Base_de_Datos.DB;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using MediatR;
using ms_categorias.CQRS.Querys;
using ms_categorias.CQRS.Commands;

namespace ms_categorias.Negocio
{
    public class NegocioCategorias : INegocioCategorias
    {
        private readonly RRHHContext _db;
        private readonly IMapper _mapper;
        private readonly IMediator _mediator;

        public NegocioCategorias(RRHHContext db, IMapper mapper, IMediator mediator)
        {
            _db = db;
            _mapper = mapper;
            _mediator = mediator;
        }

        //Command
        public async Task<bool> BorrarCategoria(int codCategoria)
        {
            return await _mediator.Send(new DeleteCategoriaQuery { CodCategoria = codCategoria });

        }

        //Commmand
        public async Task<bool>CrearCategoria(Categoria categoria)
        {
            return await _mediator.Send(new PostCategoriaQuery { UnCategoria = categoria });
        }

        //Query
        public async Task<Categoria>GetCategoria(int codCategoria)
        {
            return await _mediator.Send(new GetCategoriaQuery { codCategoria = codCategoria });
        }

        //Query
        public async Task<List<Categoria>> GetCategorias()
        {
            return await _mediator.Send(new GetCategoriasQuery());
        }

        //Command
        public void ModificarCategoria(int codCategoria,Categoria categoria)
        {
            var result = _db.TblCategorias.FirstOrDefault(c => c.CodCategoria == codCategoria);

            if (categoria.Level != null)
            {
                result.Level = categoria.Level;
            }

            if (categoria.NombreCategoria != null)
            {
                result.NombreCategoria = categoria.NombreCategoria;
            }

            if (categoria.Skill != null)
            {
                result.Skill = categoria.Skill;
            }

            _db.Entry(result).State = EntityState.Modified;
            _db.SaveChanges();
        }
    }
}
